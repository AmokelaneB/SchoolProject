﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GradStockUp
{
    public class CustomerDetails
    {
        public string CustomerName
        {
            get;
            set;
        }
        public string RentalID
        {
            get;
            set;
        }

        public string PurchaseID
        {
            get;
            set;
        }
        public string EmployeeName
        {
            get;
            set;
        }

    }
}