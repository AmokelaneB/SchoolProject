﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GradStockUp
{
    public class AddedToListItems
    {
        public string Institution {
            get;
            set;
        }
        public string Faculty
        {
            get;
            set;
        }

        public string StockType
        {
            get;
            set;
        }
        public string TransactionType
        {
            get;
            set;
        }
        public string Colour
        {
            get;
            set;
        }
        public string HeadSize
        {
            get;
            set;
        }

        public string HeightSize
        {
            get;
            set;
        }
        public string Price
        {
            get;
            set;
        }

        public string HoodSize
        {
            get;
            set;
        
        }
    }
}